<div id="content">
<h1>Nuevo Adult@ Mayor</h1>

<?php include_partial('form', array('form' => $form)) ?>
</div>